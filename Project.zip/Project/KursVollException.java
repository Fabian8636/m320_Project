public class KursVollException extends Exception {
    public KursVollException(String message) { super(message); }
}
